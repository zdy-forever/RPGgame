Final full-suite evidence only. JUnit and JaCoCo XML copied unchanged from generated Gradle output.
The terminal output was supplied by the user; it is not a separately captured agent build log.
manifest.json records commands, timestamps, counters and SHA-256 hashes.
No baseline or intermediate run is included.

Final CI evidence for commit 4bb2a4f4ad523fb1ba481eb353146fa2e6ad54f8, job #7719170.
ci-artifacts.zip is the original GitLab archive download, unchanged. Extract it to view:
- Activity_2/core/build/reports/tests/test/index.html
- Activity_2/lwjgl3/build/reports/tests/test/index.html
- Activity_2/core/build/reports/jacoco/test/html/index.html
The archive contains both Gradle test HTML trees and core JaCoCo HTML/XML.
JUnit XML was uploaded separately by CI and is not part of this archive download.
Test totals here are taken from the Gradle HTML root summaries, not reconstructed XML.
jacoco/jacocoTestReport.xml is an unchanged convenience copy from ci-artifacts.zip.
ci-build-excerpt.txt preserves the command, tasks and result from the rendered job log;
it omits checkout, cache, upload and other sections, and removes line-number gutters.
manifest.json matches RESULTS.json and records provenance, counters and SHA-256 hashes.
There are no baseline or intermediate coverage reports in this evidence bundle.
